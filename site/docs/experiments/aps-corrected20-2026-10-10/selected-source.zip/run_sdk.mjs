// Probity-operated characterization of unchanged, selected APS source.
// This harness is not an independent verifier: it calls the original SDK.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

const [sdkRoot, fixturePath, sourcePin, outputPath] = process.argv.slice(2);
const supportedPins = new Set([
  'c31d94aad86713ae9b2e4cbc811deeab4b5d91ed',
  '348c238b634b1d2d392c5e4c818398285bf8634d',
]);
assert(sdkRoot && fixturePath && sourcePin && outputPath, 'four explicit arguments required');
assert(supportedPins.has(sourcePin), 'unsupported source head');
const fixtureBytes = await readFile(fixturePath);
assert.equal(createHash('sha256').update(fixtureBytes).digest('hex'),
  '9fce76dbf13de9749a2ef52c8dedecce08e4874da0203b39a7d941eb479b5ac5');
const fixture = JSON.parse(fixtureBytes.toString('utf8'));
assert.equal(fixture.cases.length, 20);
const { verifyPassportV2 } = await import(pathToFileURL(
  resolve(sdkRoot, 'src/v2/identity-binding/passport.ts')).href);
assert.equal(typeof verifyPassportV2, 'function');
const rows = [];
const mismatches = [];
for (const test of fixture.cases) {
  const requests = [];
  const options = { now: test.now };
  if (test.resolver === 'table') {
    options.resolve_key = async (request) => {
      requests.push(structuredClone(request));
      const matches = fixture.key_resolver.entries.filter((entry) =>
        entry.controller === request.controller
        && entry.verification_method === request.verification_method);
      assert(matches.length <= 1, 'supplied fixture table is ambiguous');
      const answer = matches[0];
      if (!answer) return { state: 'not_found' };
      if (answer.outcome !== 'resolved') return { state: answer.outcome };
      return { state: 'resolved', public_key_hex: answer.public_key_hex };
    };
  } else assert.equal(test.resolver, 'none');
  const actual = await verifyPassportV2(structuredClone(test.passport), options);
  const agrees = isDeepStrictEqual(actual, test.verification)
    && isDeepStrictEqual(requests, test.resolver_requests ?? []);
  if (!agrees) mismatches.push(test.name);
  rows.push({ name: test.name, actual, publishedObservation: test.verification,
    resolverRequests: requests, agrees,
    draftAssignmentUndetermined: test.sdk_observation !== undefined,
    annotation: test.sdk_observation ?? null });
}

// The corrected twenty-case corpus has no ambiguous-resolver case.
// These separate, derived cases reuse its unchanged valid did:web passport.
// Both supplied ambiguity answers must remain unresolved after the repair.
const web = fixture.cases.find((test) => test.name === 'valid-did-web-resolved');
assert(web);
const webKey = fixture.key_resolver.entries.find((entry) =>
  entry.controller === web.passport.agent_id).public_key_hex;
const repaired = sourcePin.startsWith('348c238b');
const answers = [
  { name: 'resolved-same-key', answer: { state: 'resolved', public_key_hex: webKey },
    expected: { state: 'valid', code: 'OK', proof_of_possession: true, key_authority: 'verified' } },
  ...[false, true].map((withKey) => ({
    name: withKey ? 'ambiguous-with-attached-matching-key' : 'ambiguous-without-key',
    answer: withKey ? { state: 'ambiguous', public_key_hex: webKey } : { state: 'ambiguous' },
    expected: { state: repaired ? 'indeterminate' : 'invalid', code: 'PASSPORT_KEY_AMBIGUOUS',
      proof_of_possession: true, key_authority: repaired ? 'unresolved' : 'rejected' },
  })),
  ...['unreachable', 'not_found', 'malformed', 'unsupported'].map((state) => ({
    name: 'resolver-' + state, answer: { state },
    expected: { state: state === 'unreachable' ? 'indeterminate' : 'invalid',
      code: 'PASSPORT_KEY_' + state.toUpperCase(), proof_of_possession: true,
      key_authority: state === 'unreachable' ? 'unresolved' : 'rejected' },
  })),
];
const derived = [];
for (const test of answers) {
  const requests = [];
  const actual = await verifyPassportV2(structuredClone(web.passport), {
    now: web.now,
    resolve_key: async (request) => {
      requests.push(structuredClone(request));
      return structuredClone(test.answer);
    },
  });
  const agrees = isDeepStrictEqual(actual, test.expected)
    && isDeepStrictEqual(requests, web.resolver_requests);
  if (!agrees) mismatches.push('derived/' + test.name);
  derived.push({ ...test, actual, resolverRequests: requests, agrees,
    sourcePassportUnchanged: true, sourceCase: web.name,
    normativeScope: ['not_found', 'malformed', 'unsupported'].includes(test.answer.state)
      ? 'Literal SDK characterization; own-key normative mapping unresolved'
      : 'Separate authority/possession boundary characterization' });
}
const report = {
  schema: 'probity.lab.aps-selected-sdk-characterization/v1',
  at: new Date().toISOString(), sourcePin, fixtureCommit:
    '407ca2d5ad10c846860ad1b6faafc971ae9690e5',
  operator: 'Probity', readerIsIndependentVerifier: false,
  node: process.version, runtimeVersions: process.versions,
  selectedSourceProjection: true, packageEntryExportTested: false,
  correctedCorpusCases: rows, separateDerivedCases: derived,
  mismatches, status: mismatches.length === 0 ? 'PASS' : 'ADVERSE',
  limits: [
    'Original selected SDK source function executed; not whole SDK or package qualification.',
    'This same-source SDK characterization is distinct from the independent Python reader.',
    'Ambiguous resolver answers are supplied synthetic data, not authenticated historical DID observations.',
    'The five corpus SDK annotations and other unresolved own-key outcomes are not forced normative assignments.',
    'No package release, host adoption, federation enrollment or commercial agreement.',
  ],
};
await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ sourcePin, corpus: rows.length, derived: derived.length,
  mismatches, status: report.status }));
process.exitCode = mismatches.length === 0 ? 0 : 1;
