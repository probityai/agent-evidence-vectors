// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
// Agent Passport System — W3C DID & Verifiable Credentials Types
// Implements W3C DID Core (https://www.w3.org/TR/did-core/)
// and W3C VC Data Model 2.0 (https://www.w3.org/TR/vc-data-model-2.0/)

// ── DID Document (W3C DID Core) ──

/**
 * W3C DID Core DID Document with all five verification relationships
 * typed: `authentication`, `assertionMethod`, `capabilityDelegation`,
 * `keyAgreement`, `capabilityInvocation`. Each is an array of references
 * (key IDs) into `verificationMethod[]`.
 */
export interface DIDDocument {
  '@context': string[]
  id: string                           // did:aps:<hex-public-key>
  controller: string | string[]        // DID of the controlling entity
  verificationMethod: VerificationMethod[]
  authentication: string[]             // refs to verification methods
  assertionMethod: string[]            // for signing VCs
  capabilityDelegation?: string[]      // for issuing delegations
  keyAgreement?: string[]              // refs to verification methods used for key agreement (X25519, etc.)
  capabilityInvocation?: string[]      // refs to verification methods authorized to invoke capabilities
  service?: ServiceEndpoint[]
  created: string
  updated: string
}

export interface VerificationMethod {
  id: string                           // did:aps:<key>#key-1
  type: 'Ed25519VerificationKey2020'
  controller: string
  publicKeyMultibase: string           // z-prefixed base58btc of Ed25519 public key
}

export interface ServiceEndpoint {
  id: string
  type: string
  serviceEndpoint: string
}

// ── Verifiable Credential (W3C VC Data Model 2.0) ──

export interface VerifiableCredential {
  '@context': string[]
  id: string
  type: string[]
  issuer: string | { id: string; name?: string }
  issuanceDate: string
  expirationDate?: string
  credentialSubject: Record<string, unknown>
  proof: LinkedDataProof
}

export interface LinkedDataProof {
  type: 'Ed25519Signature2020'
  created: string
  verificationMethod: string           // did:aps:<key>#key-1
  proofPurpose: 'assertionMethod' | 'authentication' | 'capabilityDelegation' | 'capabilityInvocation'
  /** Verifier-supplied nonce this proof answers. Bound into the signed bytes
   *  along with the rest of the proof configuration, so it cannot be rewritten
   *  to readdress the proof to a different verifier. Consumption (refusing a
   *  nonce already seen) is relying-party state and is not done here; the
   *  verified value is returned so the caller can consume it. */
  challenge?: string
  /** Verifier-supplied domain this proof is addressed to. Bound into the
   *  signed bytes on the same terms as `challenge`. */
  domain?: string
  proofValue: string                   // base64url-encoded Ed25519 signature
}

// ── Verifiable Presentation ──

export interface VerifiablePresentation {
  '@context': string[]
  id: string
  type: string[]
  holder: string                       // DID of the presenting agent
  verifiableCredential: VerifiableCredential[]
  proof: LinkedDataProof
}

// ── Credential Subject types for each protocol artifact ──

export interface PassportCredentialSubject {
  id: string                           // DID of the agent
  agentName: string
  ownerAlias: string
  mission: string
  capabilities: string[]
  runtime: {
    platform: string
    models: string[]
  }
  beneficiary?: string
}

export interface DelegationCredentialSubject {
  id: string                           // DID of the delegate
  delegatedBy: string                  // DID of the delegator
  scope: string[]
  spendLimit?: number
  maxDepth: number
  currentDepth: number
  expiresAt: string
}

export interface FloorAttestationCredentialSubject {
  id: string                           // DID of the attesting agent
  floorVersion: string
  principles: string[]
  extensions?: string[]
  attestedAt: string
}

export interface PolicyReceiptCredentialSubject {
  id: string                           // DID of the acting agent
  intentId: string
  actionType: string
  target: string
  verdict: 'approve' | 'deny' | 'escalate'
  rationale: string
  signatureChain: {
    intentSignature: string
    evaluationSignature: string
    receiptSignature: string
  }
}

// ── DID Resolution ──

export interface DIDResolutionResult {
  didDocument: DIDDocument | null
  didDocumentMetadata: {
    created: string
    updated: string
    deactivated?: boolean
  }
  didResolutionMetadata: {
    contentType: string
    error?: string
  }
}


// ══════════════════════════════════════════════════════════════════
// Entity Verification v1.0 — adopted from WG conformance testing
// ══════════════════════════════════════════════════════════════════

/** DID resolution status — makes failure mode visible in the artifact */
export type DIDResolutionStatus = 'live' | 'cached' | 'failed'

/** Cached DID resolution entry */
export interface DIDResolutionCacheEntry {
  did: string
  publicKey: string
  resolvedAt: string
  expiresAt: string
  status: DIDResolutionStatus
}

/** Public proof surface — minimum fields a verifier can rely on without authentication */
export interface PublicProofSurface {
  entity_id: string
  name: string
  status: string
  entity_type: string
  authority_ceiling: string[]
  verified_at: string
}

/** Full entity verification result */
export interface EntityVerificationResult {
  /** Overall pass/fail */
  verified: boolean
  /** DID resolution status */
  didResolutionStatus: DIDResolutionStatus
  /** Resolved Ed25519 public key (hex) */
  resolvedPublicKey: string | null
  /** Entity from Corpo API (or equivalent) */
  entity: PublicProofSurface | null
  /** When the DID was resolved */
  resolvedAt: string | null
  /** If cached, when the cache entry was created */
  cachedAt?: string
  /** Sender ID (QSP-1 §4: Trunc16(SHA-256(pubkey))) */
  senderId: string | null
  /** Error details */
  errors: string[]
}
